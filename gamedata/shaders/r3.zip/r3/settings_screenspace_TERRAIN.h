// [ SETTINGS ] [ Terrain ]

#define TERRAIN_WATER_LEVEL 1.5 // Max water level

#define TERRAIN_POM_STEPS_MAX 12 // More samples generate smoother results. You can lower this value to improve performance.
#define TERRAIN_POM_STEPS_MIN 3 // Minimum quantity of steps

#define TERRAIN_POM_AO 0.125f // Basic ambient occlusion strength
#define TERRAIN_POM_PLANE 0.5 // [ 0.5f ~ 1.0f ]
#define TERRAIN_POM_RANGE 20 // Max distance of the parallax rendering

#define TERRAIN_PUDDLES_RANGE 100.f
#define TERRAIN_PUDDLES_RIPPLES_RANGE 25.f

// #define TERRAIN_DISABLE_MIXED_PUDDLES //Отключает автогенерацию луж поверх параллаксных
