#include "common.h"

//////////////////////////////////////////////////////////////////////////////////////////
// Vertex
v2p_TL main(v_TL_positiont I)
{
    v2p_TL O;

    //	O.HPos = P;

    {
        I.P.xy += 0.5f;
        //		O.HPos.x = I.P.x/1024 * 2 - 1;
        //		O.HPos.y = (I.P.y/768 * 2 - 1)*-1;
        O.HPos.x = I.P.x * screen_res.z * 2 - 1;
        O.HPos.y = (I.P.y * screen_res.w * 2 - 1) * -1;
        O.HPos.zw = I.P.zw;
    }

    O.Tex0 = I.Tex0;
    O.Color = float4(I.Color.bgr * 4, 1.0f); //	swizzle vertex colour

    return O;
}