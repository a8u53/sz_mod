// HUD blood splatter - jittered UV-cell placement.
// Each cell gets an independently randomized stamp center, atlas variant,
// rotation and scale. Unlike the old local-UV tiling, the stamp is positioned
// inside the cell rather than filling every cell edge-to-edge.
Texture2D s_hud_blood;
uniform float4 ssfx_hud_blood_params; // x: contamination intensity (0 = off, 1 = full)

float hud_blood_hash(float2 p)
{
    return frac(sin(dot(p, float2(127.1f, 311.7f))) * 43758.5453f);
}

float2 hud_blood_rotate(float2 p, float angle)
{
    float s = sin(angle);
    float c = cos(angle);
    p -= 0.5f;
    return float2(p.x * c - p.y * s, p.x * s + p.y * c) + 0.5f;
}

float4 hud_blood_stamp(Texture2D tex, float2 uv, float2 cell, float grid_scale,
                       float activation, float size_min, float size_max,
                       float alpha_gain, float seed_offset)
{
    float seed = hud_blood_hash(cell + seed_offset);
    float enabled = step(1.0f - activation, seed);

    float2 center = float2(
        lerp(0.28f, 0.72f, hud_blood_hash(cell + seed_offset + 11.7f)),
        lerp(0.28f, 0.72f, hud_blood_hash(cell + seed_offset + 29.3f))
    );

    float size = lerp(size_min, size_max, hud_blood_hash(cell + seed_offset + 47.9f));
    float angle = floor(hud_blood_hash(cell + seed_offset + 61.1f) * 4.0f)
                  * 1.57079632679f;

    float2 local = frac(uv * grid_scale);
    float2 stamp_coord = (local - center) / size + 0.5f;
    stamp_coord = hud_blood_rotate(stamp_coord, angle);

    // Keep sampling inside the selected 2x2 atlas quadrant.
    float inside = step(0.0f, stamp_coord.x) * step(0.0f, stamp_coord.y) *
                   step(stamp_coord.x, 1.0f) * step(stamp_coord.y, 1.0f);

    float variant = floor(hud_blood_hash(cell + seed_offset + 83.4f) * 4.0f);
    float2 quadrant = float2(fmod(variant, 2.0f), floor(variant * 0.5f));
    float2 atlas_uv = quadrant * 0.5f + 0.035f + saturate(stamp_coord) * 0.43f;

    float2 du = ddx(uv * grid_scale) / size;
    float2 dv = ddy(uv * grid_scale) / size;
    float s = sin(angle), c = cos(angle);
    float2 grad_x = float2(du.x*c - du.y*s, du.x*s + du.y*c) * 0.43f;
    float2 grad_y = float2(dv.x*c - dv.y*s, dv.x*s + dv.y*c) * 0.43f;

    float4 stamp = tex.SampleGrad(smp_base, atlas_uv, grad_x, grad_y);
    stamp.a *= enabled * inside * alpha_gain;
    return stamp;
}

float4 ssfx_hud_blood(Texture2D blood_tex, float2 uv, float uv_scale)
{
    // Broad primary stains: sparse, large, and independently offset.
    float primary_grid = uv_scale * 1.45f;
    float2 primary_cell = floor(uv * primary_grid);
    float4 primary = hud_blood_stamp(
        blood_tex, uv, primary_cell, primary_grid,
        0.48f, 0.78f, 1.08f, 1.0f, 13.0f
    );

    // Broad low-opacity coverage pass. A different grid scale means small
    // UV islands (for example the palm) do not keep falling into the same
    // empty primary cells.
    float coverage_grid = uv_scale * 0.92f;
    float2 coverage_cell = floor(uv * coverage_grid);
    float4 coverage = hud_blood_stamp(
        blood_tex, uv, coverage_cell, coverage_grid,
        0.72f, 0.88f, 1.12f, 0.48f, 347.0f
    );

    // Secondary smaller splashes remain sparse.
    float secondary_grid = uv_scale * 3.2f;
    float2 secondary_cell = floor(uv * secondary_grid);
    float4 secondary = hud_blood_stamp(
        blood_tex, uv, secondary_cell, secondary_grid,
        0.18f, 0.34f, 0.52f, 0.36f, 191.0f
    );

    float alpha_sum = primary.a + coverage.a + secondary.a;
    float alpha = saturate(max(max(primary.a, coverage.a), secondary.a));
    float3 color = (primary.rgb * primary.a +
                    coverage.rgb * coverage.a +
                    secondary.rgb * secondary.a) /
                   max(alpha_sum, 0.001f);
    return float4(color, alpha);
}
